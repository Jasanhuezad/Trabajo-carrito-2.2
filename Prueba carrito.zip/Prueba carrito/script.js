function showView(viewId) {
    // Oculta todas las vistas
    var views = document.querySelectorAll('.view');
    views.forEach(function(view) {
        view.style.display = 'none';
    });

    // Muestra la vista seleccionada
    var selectedView = document.getElementById(viewId);
    if (selectedView) {
        selectedView.style.display = 'block';
    }
}

