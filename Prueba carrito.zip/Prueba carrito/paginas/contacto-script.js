document.getElementById('mostrarNumero').addEventListener('click', function() {
    document.getElementById('numeroContacto').style.display = 'block';
  });
  