document.addEventListener('DOMContentLoaded', function() {
    const message = "Hola, somos una empresa de venta de relojes con más de 20 años de experiencia. Nuestros cómodos precios son los mejores respecto al mercado. Solo necesitas tomarte un poco de tu tiempo para que puedas ver nuestros cómodos precios.";
    document.getElementById('message').textContent = message;
});
